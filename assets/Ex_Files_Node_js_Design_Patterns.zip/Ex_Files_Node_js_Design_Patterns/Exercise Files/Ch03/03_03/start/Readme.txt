This is a text version of the readme file.
