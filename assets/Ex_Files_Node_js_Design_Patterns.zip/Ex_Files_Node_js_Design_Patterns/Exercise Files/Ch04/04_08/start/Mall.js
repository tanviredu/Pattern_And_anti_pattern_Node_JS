class Mall {

    constructor() {
        this.sales = [];
    }

}

module.exports = Mall;
