Readme Markdown
================
This is the markdown version of the readme file.
