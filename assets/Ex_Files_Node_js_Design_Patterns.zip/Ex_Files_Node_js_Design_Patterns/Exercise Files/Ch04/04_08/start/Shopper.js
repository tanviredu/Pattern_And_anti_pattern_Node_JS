class Shopper {

    constructor(name) {
        this.name = name;
    }
}

module.exports = Shopper;
